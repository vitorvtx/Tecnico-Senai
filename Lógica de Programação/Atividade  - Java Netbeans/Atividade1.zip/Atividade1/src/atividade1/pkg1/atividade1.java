package atividade1.pkg1;

import java.util.Scanner;

public class atividade1 {
    
 public static void main(String[]   args) {
     
     try (
     Scanner scanner = new Scanner(System.in)) {
         
         String nome;
         float peso;
         int idade;
         float altura;
         
         
         System.out.print("Digite o nome: ");
         
         nome = scanner.nextLine();
         
         System.out.print("Digite o peso (em kg)");
         
         peso = scanner.nextFloat();
         
         System.out.print("Digite a altura (em metros): ");
         
         altura = scanner.nextFloat();
         
         System.out.print ("Digite a idade: ");
         
         idade = scanner.nextInt();
         
         System.out.println();
        
         System.out.println("--- DADOS DO USUÁRIO ---");
         
         System.out.println("Nome: " +nome);
         
         System.out.println("Peso: " + peso + " kg");
         
         System.out.println("Altura:" +altura + "m");
         
         System.out.println("Idade" +idade + " anos");
                 
         
     }
 }
         
         
}
        
        





        
